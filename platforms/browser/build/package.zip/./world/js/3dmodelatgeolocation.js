var World = {
	loaded: false,
	rotating: false,

	init: function initFn() {
		this.createModelAtLocation();
	},
	modelTree: new AR.Model("assets/tree01.wt3", {
		onLoaded: this.worldLoaded,
		scale: {
			x: 1,
			y: 1,
			z: 1
		}
	}),
	createTree:function (location){
		var tree = new AR.GeoObject(location, {
			drawables: {
				cam: [this.modelTree]
			}
		});

		return tree;
	},
	createModelAtLocation: function createModelAtLocationFn() {

		/*
			First a location where the model should be displayed will be defined. This location will be relativ to the user.
			10 meters away to the north. ?. 0 meters above
		*/

		/*

		Home location:
		var location = new AR.GeoLocation(55.711868, 12.570889);
		var altitude = location.altitude; //altitude = -32768
		var object = new AR.GeoObject(location);

		 var location01 = new AR.GeoLocation(55.711868, 12.570889);
		 var location02 = new AR.GeoLocation(55.711865, 12.570873);

		KEA location:
		var location = new AR.GeoLocation(55.706232, 12.539829);
		var altitude = location.altitude; //altitude = -32768
		var object = new AR.GeoObject(location);

		 var location01 = new AR.GeoLocation(55.706232, 12.539829);
		 var location02 = new AR.GeoLocation(55.706190, 12.539850);


		Relative location:
		var location01 = new AR.RelativeLocation(null, 5, 0, 2);

		*/

		var location01 = new AR.GeoLocation(55.711868, 12.570889);
		var location02 = new AR.GeoLocation(55.711865, 12.570873);

        var indicatorImage = new AR.ImageResource("assets/indi.png");

        var indicatorDrawable = new AR.ImageDrawable(indicatorImage, 0.1, {
            verticalAnchor: AR.CONST.VERTICAL_ANCHOR.TOP
        });

		/*
			Putting it all together the location and 3D model is added to an AR.GeoObject.
		*/

		var obj = new AR.GeoObject(location01, {
            drawables: {
               cam: [this.modelTree],
               indicator: [indicatorDrawable]
            }
        });

		var t02 = this.createTree(location02);
		/*
		var t03 = this.createTree(location03);
		var t04 = this.createTree(location04);
		var t05 = this.createTree(location05);
		var t06 = this.createTree(location06);
		var t07 = this.createTree(location07);
		var t08 = this.createTree(location08);
		var t09 = this.createTree(location09);
		var t01 = this.createTree(location10);
		*/

	},

	worldLoaded: function worldLoadedFn() {
		World.loaded = true;
		var e = document.getElementById('loadingMessage');
		e.parentElement.removeChild(e);
	}
};

World.init();
